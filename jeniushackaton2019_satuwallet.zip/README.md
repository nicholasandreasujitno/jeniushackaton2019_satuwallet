# Jenius Hackathon 2019

App: Satu Wallet Xamarin Android Apps

## Getting Started

Install Visual Studio 2017 with Mobile development with .NET workload.

### Prerequisites

Our application code uses C# .NET library and Xamarin library platform. 

## Usage and Permission

This application is developed for Jenius Hackathon 2019 event only. Do not duplicate or distribute without written permission from Satu Wallet Team - Team No. 4.

## License

This project is licensed under the MIT License.


