﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//using Android.App;
//using Android.Content;
//using Android.OS;
//using Android.Runtime;
//using Android.Support.V7.App;
//using Android.Views;
//using Android.Widget;

//namespace satuwallet_android
//{
//    public class MyApp : Application
//    {
//        public void OnCreate()
//        {
//            base.OnCreate();
//        }

//        private Activity mCurrentActivity = null;
//        public Activity GetCurrentActivity()
//        {
//            return mCurrentActivity;
//        }
//        public void SetCurrentActivity(Activity mCurrentActivity)
//        {
//            this.mCurrentActivity = mCurrentActivity;
//        }
//    }
//}